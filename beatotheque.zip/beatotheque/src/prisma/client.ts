// src/prisma/client.ts
// Singleton Prisma : évite de créer trop de connexions en développement (hot-reload Next.js)

import { PrismaClient } from '@prisma/client';

// En dev, Next.js recharge les modules à chaque changement.
// Sans singleton, chaque rechargement crée une nouvelle connexion → dépasse le pool Neon.
const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
