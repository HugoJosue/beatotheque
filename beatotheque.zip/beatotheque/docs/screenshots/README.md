# Screenshots

Placez ici vos captures d'écran :

- `1-home.png`      → Page d'accueil (hero + features)
- `2-catalogue.png` → Catalogue des beats avec filtres
- `3-dashboard.png` → Dashboard producteur (liste + actions)

Vous pouvez en ajouter d'autres (login, détail beat, formulaire...).
