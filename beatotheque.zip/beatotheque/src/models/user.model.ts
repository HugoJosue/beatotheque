// src/models/user.model.ts
// Définitions TypeScript pour le modèle User

export interface UserPublic {
  id: string;
  email: string;
  createdAt: Date;
}

// Payload stocké dans le JWT
export interface JwtPayload {
  sub: string;   // userId
  email: string;
  iat?: number;
  exp?: number;
}
