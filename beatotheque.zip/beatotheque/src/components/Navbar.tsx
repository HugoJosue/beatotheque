// src/components/Navbar.tsx
// Barre de navigation responsive avec état d'authentification
'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';

interface User {
  id: string;
  email: string;
}

export function Navbar() {
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);
  const [checked, setChecked] = useState(false);

  // Vérifie si l'utilisateur est connecté à chaque navigation
  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => (r.ok ? r.json() : null))
      .then((json) => setUser(json?.data ?? null))
      .finally(() => setChecked(true));
  }, [pathname]); // Re-run quand la page change

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    window.location.href = '/';
  }

  return (
    <nav className="border-b border-[#2A2A2A] bg-[#0F0F0F]/80 backdrop-blur sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="text-xl font-extrabold tracking-tight">
          Beato<span className="text-violet-500">thèque</span>
        </Link>

        {/* Navigation principale */}
        <div className="flex items-center gap-6">
          <Link
            href="/beats"
            className={`text-sm transition ${
              pathname.startsWith('/beats') ? 'text-white font-medium' : 'text-gray-400 hover:text-white'
            }`}
          >
            Catalogue
          </Link>

          {checked && (
            <>
              {user ? (
                <>
                  <Link
                    href="/dashboard"
                    className={`text-sm transition ${
                      pathname.startsWith('/dashboard') ? 'text-white font-medium' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Dashboard
                  </Link>
                  <button onClick={handleLogout} className="text-sm text-gray-400 hover:text-white transition">
                    Déconnexion
                  </button>
                </>
              ) : (
                <>
                  <Link href="/login" className="text-sm text-gray-400 hover:text-white transition">
                    Connexion
                  </Link>
                  <Link href="/register" className="btn-primary text-sm py-1.5 px-4">
                    S&apos;inscrire
                  </Link>
                </>
              )}
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
