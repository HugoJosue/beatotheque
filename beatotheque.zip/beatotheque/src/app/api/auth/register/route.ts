// src/app/api/auth/register/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { ZodError } from 'zod';
import { registerUser } from '@/controllers/auth.controller';
import { ok, err, validationError } from '@/lib/api-response';
import { COOKIE_NAME } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { user, token } = await registerUser(body);

    // On attache le JWT dans un cookie httpOnly (inaccessible au JS côté client)
    const response = ok(user, 201);
    response.cookies.set(COOKIE_NAME, token, {
      httpOnly: true,      // Protection contre XSS
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 jours
      path: '/',
    });

    return response;
  } catch (e) {
    if (e instanceof ZodError) {
      return validationError(e.flatten().fieldErrors as Record<string, string[]>);
    }
    const error = e as Error & { statusCode?: number };
    return err(error.message, error.statusCode ?? 500);
  }
}
