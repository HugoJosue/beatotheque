// src/app/beats/page.tsx
// Liste publique des beats avec filtre de style et pagination
'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { BeatCard } from '@/components/BeatCard';

interface Beat {
  id: string;
  title: string;
  bpm: number;
  style: string;
  key: string;
  price: number;
  previewUrl: string;
  createdAt: string;
  user: { id: string; email: string };
}

interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

const STYLES = ['Tous', 'Trap', 'Lo-fi', 'Drill', 'Boom Bap', 'R&B', 'Afrobeats'];

export default function BeatsPage() {
  const [beats, setBeats] = useState<Beat[]>([]);
  const [pagination, setPagination] = useState<Pagination | null>(null);
  const [style, setStyle] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchBeats = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const params = new URLSearchParams({ page: String(page), limit: '12' });
      if (style) params.set('style', style);

      const res = await fetch(`/api/beats?${params}`);
      const json = await res.json();

      if (!json.success) throw new Error(json.error);
      setBeats(json.data.beats);
      setPagination(json.data.pagination);
    } catch {
      setError('Impossible de charger les beats.');
    } finally {
      setLoading(false);
    }
  }, [page, style]);

  useEffect(() => {
    fetchBeats();
  }, [fetchBeats]);

  const handleStyleChange = (s: string) => {
    setStyle(s === 'Tous' ? '' : s);
    setPage(1); // Réinitialise la pagination quand le filtre change
  };

  return (
    <div className="space-y-8">
      {/* En-tête */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-3xl font-bold">🎵 Catalogue</h1>
        {pagination && (
          <span className="text-gray-400 text-sm">{pagination.total} beat{pagination.total !== 1 ? 's' : ''}</span>
        )}
      </div>

      {/* Filtres de style */}
      <div className="flex flex-wrap gap-2">
        {STYLES.map((s) => (
          <button
            key={s}
            onClick={() => handleStyleChange(s)}
            className={`badge px-3 py-1.5 text-sm cursor-pointer transition ${
              (style === '' && s === 'Tous') || style === s
                ? 'bg-violet-600 text-white'
                : 'bg-[#2A2A2A] text-gray-300 hover:bg-[#333]'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Contenu */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card h-40 animate-pulse bg-[#222]" />
          ))}
        </div>
      ) : error ? (
        <div className="card text-red-400">{error}</div>
      ) : beats.length === 0 ? (
        <div className="card text-center text-gray-400 py-12">
          <p className="text-5xl mb-4">🎹</p>
          <p>Aucun beat trouvé pour ce style.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {beats.map((beat) => (
            <Link key={beat.id} href={`/beats/${beat.id}`}>
              <BeatCard beat={beat} />
            </Link>
          ))}
        </div>
      )}

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex justify-center items-center gap-4 mt-8">
          <button
            onClick={() => setPage((p) => p - 1)}
            disabled={page === 1}
            className="btn-secondary disabled:opacity-40"
          >
            ← Précédent
          </button>
          <span className="text-gray-400">
            Page {pagination.page} / {pagination.totalPages}
          </span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={page === pagination.totalPages}
            className="btn-secondary disabled:opacity-40"
          >
            Suivant →
          </button>
        </div>
      )}
    </div>
  );
}
