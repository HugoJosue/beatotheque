// src/lib/api-response.ts
// Helpers pour construire des réponses JSON cohérentes dans tous les route handlers

import { NextResponse } from 'next/server';

/** Réponse de succès standardisée */
export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

/** Réponse d'erreur standardisée */
export function err(message: string, status = 400) {
  return NextResponse.json({ success: false, error: message }, { status });
}

/** Erreur de validation Zod → formatée pour le client */
export function validationError(errors: Record<string, string[]>) {
  return NextResponse.json(
    { success: false, error: 'Données invalides', details: errors },
    { status: 422 }
  );
}
