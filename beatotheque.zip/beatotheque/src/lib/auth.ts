// src/lib/auth.ts
// Utilitaires d'authentification : lecture du cookie JWT dans les requêtes API

import { cookies } from 'next/headers';
import { verifyToken } from './jwt';
import type { JwtPayload } from '@/models/user.model';

export const COOKIE_NAME = 'beatotheque_token';

/**
 * Lit et vérifie le JWT depuis le cookie httpOnly.
 * Retourne le payload décodé, ou null si absent/invalide.
 */
export async function getAuthUser(): Promise<JwtPayload | null> {
  try {
    const cookieStore = cookies();
    const token = cookieStore.get(COOKIE_NAME)?.value;
    if (!token) return null;
    return await verifyToken(token);
  } catch {
    // Token expiré, malformé, ou clé incorrecte
    return null;
  }
}

/**
 * Comme getAuthUser mais lève une réponse 401 si non authentifié.
 * Pratique dans les route handlers pour éviter la répétition.
 */
export async function requireAuth(): Promise<JwtPayload> {
  const user = await getAuthUser();
  if (!user) {
    throw new AuthError('Non authentifié');
  }
  return user;
}

/** Erreur custom pour distinguer les 401 des 500 dans les controllers */
export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}
