// src/controllers/license.controller.ts
// Logique CRUD pour les licences — vérification ownership via le beat parent

import { prisma } from '@/prisma/client';
import { licenseSchema } from '@/lib/validations';

// ─── GET /api/beats/:id/licenses ─────────────────────────────────────────────

export async function getLicensesByBeat(beatId: string) {
  // Vérifie que le beat existe
  const beat = await prisma.beat.findUnique({ where: { id: beatId }, select: { id: true } });
  if (!beat) throw Object.assign(new Error('Beat introuvable'), { statusCode: 404 });

  return prisma.license.findMany({
    where: { beatId },
    orderBy: { price: 'asc' }, // Du moins cher au plus cher
  });
}

// ─── POST /api/beats/:id/licenses ────────────────────────────────────────────

export async function createLicense(beatId: string, body: unknown, userId: string) {
  // Seul le propriétaire du beat peut créer des licences
  const beat = await prisma.beat.findUnique({ where: { id: beatId }, select: { userId: true } });
  if (!beat) throw Object.assign(new Error('Beat introuvable'), { statusCode: 404 });
  if (beat.userId !== userId) throw Object.assign(new Error('Accès refusé'), { statusCode: 403 });

  const data = licenseSchema.parse(body);

  return prisma.license.create({ data: { ...data, beatId } });
}

// ─── PUT /api/licenses/:id ────────────────────────────────────────────────────

export async function updateLicense(id: string, body: unknown, userId: string) {
  // Remonte jusqu'au beat pour vérifier le propriétaire
  const license = await prisma.license.findUnique({
    where: { id },
    include: { beat: { select: { userId: true } } },
  });

  if (!license) throw Object.assign(new Error('Licence introuvable'), { statusCode: 404 });
  if (license.beat.userId !== userId) throw Object.assign(new Error('Accès refusé'), { statusCode: 403 });

  const data = licenseSchema.parse(body);

  return prisma.license.update({ where: { id }, data });
}

// ─── DELETE /api/licenses/:id ────────────────────────────────────────────────

export async function deleteLicense(id: string, userId: string) {
  const license = await prisma.license.findUnique({
    where: { id },
    include: { beat: { select: { userId: true } } },
  });

  if (!license) throw Object.assign(new Error('Licence introuvable'), { statusCode: 404 });
  if (license.beat.userId !== userId) throw Object.assign(new Error('Accès refusé'), { statusCode: 403 });

  await prisma.license.delete({ where: { id } });
}
