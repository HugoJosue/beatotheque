// src/components/BeatCard.tsx
// Carte beat pour la liste du catalogue

interface Beat {
  id: string;
  title: string;
  bpm: number;
  style: string;
  key: string;
  price: number;
  createdAt: string;
  user: { email: string };
}

interface Props {
  beat: Beat;
}

export function BeatCard({ beat }: Props) {
  return (
    <div className="card hover:border-violet-700/50 transition-all hover:-translate-y-0.5 cursor-pointer group">
      {/* Style badge */}
      <div className="flex items-start justify-between mb-3">
        <span className="badge bg-violet-900/60 text-violet-300 text-xs">{beat.style}</span>
        <span className="text-violet-400 font-bold">{Number(beat.price).toFixed(2)} $</span>
      </div>

      {/* Titre */}
      <h3 className="font-bold text-white text-lg leading-tight group-hover:text-violet-200 transition">
        {beat.title}
      </h3>
      <p className="text-gray-500 text-xs mt-1">par {beat.user.email}</p>

      {/* Infos techniques */}
      <div className="flex gap-3 mt-4 text-xs text-gray-400">
        <span className="flex items-center gap-1">
          <span className="text-violet-500">♩</span>
          {beat.bpm} BPM
        </span>
        <span className="flex items-center gap-1">
          <span className="text-violet-500">🎵</span>
          {beat.key}
        </span>
      </div>
    </div>
  );
}
