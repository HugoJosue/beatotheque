// src/models/beat.model.ts
// Définitions TypeScript pour le modèle Beat

import type { UserPublic } from './user.model';

export interface BeatBase {
  id: string;
  title: string;
  bpm: number;
  style: string;
  key: string;
  price: number;   // Decimal converti en number pour les réponses JSON
  previewUrl: string;
  createdAt: Date;
  userId: string;
}

// Beat enrichi avec les infos de l'auteur (réponse détaillée)
export interface BeatWithAuthor extends BeatBase {
  user: Pick<UserPublic, 'id' | 'email'>;
}

// Données acceptées pour la création/modification d'un beat
export interface BeatInput {
  title: string;
  bpm: number;
  style: string;
  key: string;
  price: number;
  previewUrl: string;
}

// Paramètres de filtrage/pagination pour GET /api/beats
export interface BeatQueryParams {
  style?: string;
  page?: number;
  limit?: number;
}
