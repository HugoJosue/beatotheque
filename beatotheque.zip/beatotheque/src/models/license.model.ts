// src/models/license.model.ts
// Définitions TypeScript pour le modèle License

export interface LicenseBase {
  id: string;
  beatId: string;
  name: string;
  price: number;
  rightsText: string;
  createdAt: Date;
}

export interface LicenseInput {
  name: string;
  price: number;
  rightsText: string;
}
