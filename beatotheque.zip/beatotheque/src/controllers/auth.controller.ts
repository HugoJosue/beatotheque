// src/controllers/auth.controller.ts
// Logique métier de l'authentification — appelée depuis les route handlers API

import bcrypt from 'bcryptjs';
import { prisma } from '@/prisma/client';
import { signToken } from '@/lib/jwt';
import { registerSchema, loginSchema } from '@/lib/validations';
import type { UserPublic } from '@/models/user.model';

// ─── Register ─────────────────────────────────────────────────────────────────

export async function registerUser(body: unknown): Promise<{
  user: UserPublic;
  token: string;
}> {
  // Validation des données entrantes
  const data = registerSchema.parse(body);

  // Vérification unicité de l'email
  const existing = await prisma.user.findUnique({ where: { email: data.email } });
  if (existing) {
    throw Object.assign(new Error('Cet email est déjà utilisé'), { statusCode: 409 });
  }

  // Hachage du mot de passe (coût 12 = bon compromis sécurité/performance)
  const passwordHash = await bcrypt.hash(data.password, 12);

  const user = await prisma.user.create({
    data: { email: data.email, passwordHash },
    select: { id: true, email: true, createdAt: true }, // Jamais retourner passwordHash
  });

  const token = await signToken({ sub: user.id, email: user.email });

  return { user, token };
}

// ─── Login ────────────────────────────────────────────────────────────────────

export async function loginUser(body: unknown): Promise<{
  user: UserPublic;
  token: string;
}> {
  const data = loginSchema.parse(body);

  const user = await prisma.user.findUnique({ where: { email: data.email } });

  // Message d'erreur générique : ne pas révéler si l'email existe ou non
  const INVALID_MSG = 'Email ou mot de passe incorrect';

  if (!user) throw Object.assign(new Error(INVALID_MSG), { statusCode: 401 });

  const valid = await bcrypt.compare(data.password, user.passwordHash);
  if (!valid) throw Object.assign(new Error(INVALID_MSG), { statusCode: 401 });

  const token = await signToken({ sub: user.id, email: user.email });

  return {
    user: { id: user.id, email: user.email, createdAt: user.createdAt },
    token,
  };
}

// ─── Me ───────────────────────────────────────────────────────────────────────

export async function getMe(userId: string): Promise<UserPublic> {
  const user = await prisma.user.findUniqueOrThrow({
    where: { id: userId },
    select: { id: true, email: true, createdAt: true },
  });
  return user;
}
