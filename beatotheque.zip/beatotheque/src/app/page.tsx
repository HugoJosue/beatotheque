// src/app/page.tsx
// Page d'accueil — présentation de l'application

import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center gap-8">
      {/* Hero */}
      <div className="space-y-4">
        <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight">
          Beato
          <span className="text-violet-500">thèque</span>
        </h1>
        <p className="text-lg text-gray-400 max-w-xl mx-auto">
          La bibliothèque de beats pour producteurs et artistes. Explorez, gérez et
          licenciez vos productions musicales en toute simplicité.
        </p>
      </div>

      {/* CTA */}
      <div className="flex flex-wrap gap-4 justify-center">
        <Link href="/beats" className="btn-primary text-lg px-8 py-3 rounded-xl">
          🎵 Explorer les beats
        </Link>
        <Link href="/register" className="btn-secondary text-lg px-8 py-3 rounded-xl">
          Créer un compte
        </Link>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12 w-full max-w-3xl">
        {[
          { icon: '🎛️', title: 'Catalogue complet', desc: 'BPM, tonalité, style — tout est indexé.' },
          { icon: '🔐', title: 'Ownership clair', desc: 'Gérez uniquement vos propres beats.' },
          { icon: '📄', title: 'Licences flexibles', desc: 'Lease, exclusif, custom — vous décidez.' },
        ].map((f) => (
          <div key={f.title} className="card text-left space-y-2">
            <div className="text-3xl">{f.icon}</div>
            <h3 className="font-bold text-white">{f.title}</h3>
            <p className="text-sm text-gray-400">{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
