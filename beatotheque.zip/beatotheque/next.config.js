/** @type {import('next').NextConfig} */
const nextConfig = {
  // Permet d'accéder aux variables d'env côté serveur uniquement (pas exposées au client)
  experimental: {},
};

module.exports = nextConfig;
